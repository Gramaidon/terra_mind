import { create } from "zustand";

export interface EmotionLabel {
  timestamp: number;
  valence: number;
  arousal: number;
}

export interface EEGDataPoint {
  time: number;
  theta: number;
  alpha: number;
  beta: number;
  gamma: number;
}

interface ExperimentState {
  valence: number;
  arousal: number;
  videoTime: number;
  sessionTime: number;
  isRecording: boolean;
  isFullscreen: boolean;
  labels: EmotionLabel[];
  eegData: EEGDataPoint[];

  theme: "dark" | "light";
  toggleTheme: () => void;
  setValence: (v: number) => void;
  setArousal: (a: number) => void;
  setEmotion: (v: number, a: number) => void;
  setVideoTime: (time: number) => void;
  tickSessionTime: () => void;
  toggleRecording: () => void;
  setFullscreen: (val: boolean) => void;
  addLabel: () => void;
  addEegData: (data: Omit<EEGDataPoint, "time">) => void;
  clearSession: () => void;
}

export const useExperimentStore = create<ExperimentState>((set, get) => ({
  valence: 5,
  arousal: 5,
  videoTime: 0,
  sessionTime: 0,
  isRecording: false,
  isFullscreen: false,
  theme: "dark",
  labels: [],
  eegData: [],

  /** Toggles the UI theme between dark and light modes */
  toggleTheme: () =>
    set((state) => ({ theme: state.theme === "dark" ? "light" : "dark" })),

  /** Sets the current valence (1-9) value */
  setValence: (valence) => set({ valence }),

  /** Sets the current arousal (1-9) value */
  setArousal: (arousal) => set({ arousal }),

  /** Sets both valence and arousal (1-9 scale) simultaneously */
  setEmotion: (valence, arousal) => set({ valence, arousal }),

  /** Updates the synchronized video time */
  setVideoTime: (videoTime) => set({ videoTime }),

  /** Increments the active session elapsed time by 1 second */
  tickSessionTime: () =>
    set((state) => ({ sessionTime: state.sessionTime + 1 })),

  /** Toggles the active recording state for the session */
  toggleRecording: () =>
    set((state) => {
      const isNowRecording = !state.isRecording;
      return {
        isRecording: isNowRecording,
        sessionTime: isNowRecording ? state.sessionTime : 0, // Reset timer ke 0 saat session stop
        videoTime: isNowRecording ? state.videoTime : 0, // Sinkronisasi reset video ke 0
      };
    }),

  /** Updates whether the view is currently in fullscreen mode */
  setFullscreen: (isFullscreen) => set({ isFullscreen }),

  /** Captures the current valence, arousal, and session time and adds it to the label history */
  addLabel: () => {
    const { sessionTime, valence, arousal, labels } = get();
    // Prevent exactly duplicate timestamps if submitted extremely fast, or just allow it
    set({
      labels: [...labels, { timestamp: sessionTime, valence, arousal }],
    });
  },

  /** Adds a new simulated or real EEG reading to the current active array. Keeps recent 50 points */
  addEegData: (data) => {
    set((state) => {
      const now = Date.now();
      const newEeg = [...state.eegData, { ...data, time: now }];
      // Keep last 50 data points for performance
      if (newEeg.length > 50) {
        newEeg.shift();
      }
      return { eegData: newEeg };
    });
  },

  /** Removes all existing session labels and resets the experiment context back to defaults */
  clearSession: () =>
    set({
      labels: [],
      eegData: [],
      videoTime: 0,
      sessionTime: 0,
      isRecording: false,
      valence: 5,
      arousal: 5,
    }),
}));

const channel = new BroadcastChannel("affective-lab-sync");
let isReceiving = false;

// Handle messages across browser tabs
channel.onmessage = (e) => {
  isReceiving = true;
  useExperimentStore.setState(e.data);
  isReceiving = false;
};

// Subscribe to state changes and broadcast to other tabs
useExperimentStore.subscribe((state, prevState) => {
  if (!isReceiving) {
    // Prevent flooding the channel and overwriting other tabs by ignoring purely eegData updates
    if (state.eegData !== prevState.eegData) {
      const { eegData: _, ...restState } = state;
      const { eegData: __, ...restPrevState } = prevState;
      if (JSON.stringify(restState) === JSON.stringify(restPrevState)) {
        return; // Only eegData changed, do not broadcast
      }
    }
    
    // Strip functions before broadcasting to avoid DataCloneError
    const stateToBroadcast = Object.fromEntries(
      Object.entries(state).filter(([_, value]) => typeof value !== "function")
    );
    channel.postMessage(stateToBroadcast);
  }
});
