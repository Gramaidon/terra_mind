import React, { useRef, useState } from "react";
import { useExperimentStore } from "../store";
import { Smile, Frown, Flame, Snowflake } from "lucide-react";
import { motion } from "motion/react";

export function EmotionMap({
  variant = "default",
  className = "",
  isTabletContext = false,
}: {
  variant?: "default" | "compact" | "sam";
  className?: string;
  isTabletContext?: boolean;
}) {
  const { valence, arousal, setEmotion, isRecording, addLabel } =
    useExperimentStore();
  const mapRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  // Calculate X position from 1-9 scale to percentage (0-100)
  const xPos = ((valence - 1) / 8) * 100;
  // Calculate Y position: Arousal: 9 is top (0% top), 1 is bottom (100% top)
  const yPos = (1 - (arousal - 1) / 8) * 100;

  // Calculate and update emotion values based on pointer position relative to map element
  const handleInteraction = (e: React.MouseEvent | React.TouchEvent) => {
    if (!mapRef.current) return;

    const rect = mapRef.current.getBoundingClientRect();

    let clientX, clientY;
    if ("touches" in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = (e as React.MouseEvent).clientX;
      clientY = (e as React.MouseEvent).clientY;
    }

    const x = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
    const y = Math.max(0, Math.min(1, (clientY - rect.top) / rect.height));

    const newValence = 1 + x * 8;
    const newArousal = 1 + (1 - y) * 8;

    setEmotion(Number(newValence.toFixed(1)), Number(newArousal.toFixed(1)));
  };

  // Handle pointer down (mouse/touch start)
  const handlePointerDown = (e: React.MouseEvent | React.TouchEvent) => {
    setIsDragging(true);
    handleInteraction(e);
  };

  // Handle pointer move (mouse/touch drag)
  const handlePointerMove = (e: React.MouseEvent | React.TouchEvent) => {
    if (isDragging) {
      handleInteraction(e);
    }
  };

  // Handle pointer up (mouse/touch end)
  const handlePointerUp = () => {
    setIsDragging(false);
    if (isRecording) {
      addLabel(); // save label automatically if recording is active
    }
  };

  if (variant === "sam") {
    // Exact look as the SAM chart (Self-Assessment Manikin)
    return (
      <div
        className={`flex flex-col items-center w-full mx-auto bg-white p-2 pb-3 mb-1 select-none touch-none text-gray-800 rounded-lg shadow-[0_0_15px_rgba(0,0,0,0.05)] border border-gray-100 ${
          className || "max-w-[240px] sm:max-w-[280px]"
        }`}
      >
        {/* Main Chart Row */}
        <div className="flex w-full items-stretch">
          {/* Y-axis Text */}
          <div className="flex items-center justify-center w-[10%] shrink-0">
            <span className="font-bold -rotate-90 whitespace-nowrap text-[8px] sm:text-[10px] uppercase tracking-wider">
              Arousal
            </span>
          </div>

          {/* Y-axis labels & images */}
          <div className="flex flex-col justify-between items-end w-[16%] pr-1 sm:pr-2 py-0 shrink-0">
            {[9, 7, 5, 3, 1].map((val) => (
              <div
                key={`arousal-${val}`}
                className="flex items-center gap-1 h-[14%]"
              >
                <div className="h-full aspect-[4/5] overflow-hidden flex items-center justify-center">
                  <img
                    src={`/arousal ${Math.floor(val / 2) + 1}.png`}
                    alt={`Arousal ${val}`}
                    className="w-full h-full object-contain mix-blend-multiply"
                    onError={(e) => {
                      // Fallback text if image not found
                      e.currentTarget.style.display = "none";
                      e.currentTarget.parentElement!.innerHTML =
                        '<div class="text-[8px] text-gray-400">IMG</div>';
                    }}
                  />
                </div>
                <span className="text-[10px] font-bold w-2 text-right font-mono">
                  {val}
                </span>
              </div>
            ))}
          </div>

          {/* Graph Area */}
          <div className="w-[66%] flex flex-col relative aspect-square shrink-0">
            <div
              ref={mapRef}
              className="absolute inset-0 bg-white border-l border-b border-gray-400 cursor-crosshair"
              onMouseDown={handlePointerDown}
              onMouseMove={handlePointerMove}
              onMouseUp={handlePointerUp}
              onMouseLeave={handlePointerUp}
              onTouchStart={handlePointerDown}
              onTouchMove={handlePointerMove}
              onTouchEnd={handlePointerUp}
            >
              {/* Ticks for 1-9 */}
              <div className="absolute inset-x-0 bottom-0 flex justify-between h-1">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((i) => (
                  <div
                    key={`x-tick-${i}`}
                    className="w-px h-1 bg-gray-400 translate-y-[1px]"
                  ></div>
                ))}
              </div>
              <div className="absolute inset-y-0 left-0 flex flex-col justify-between w-1 h-full">
                {[9, 8, 7, 6, 5, 4, 3, 2, 1].map((i) => (
                  <div
                    key={`y-tick-${i}`}
                    className="h-px w-1 bg-gray-400 -translate-x-[1px]"
                  ></div>
                ))}
              </div>

              {/* Dashed center lines (5,5) */}
              <div className="absolute top-1/2 left-0 right-0 h-px border-t border-dashed border-gray-400 -translate-y-1/2 pointer-events-none"></div>
              <div className="absolute left-1/2 top-0 bottom-0 w-px border-l border-dashed border-gray-400 -translate-x-1/2 pointer-events-none"></div>

              {/* Red Dot indicating selection */}
              <motion.div
                className="absolute w-3 h-3 md:w-4 md:h-4 bg-[#e62020] rounded-full pointer-events-none"
                style={{
                  left: `${xPos}%`,
                  top: `${yPos}%`,
                  x: "-50%",
                  y: "-50%",
                }}
                transition={{ type: "spring", stiffness: 400, damping: 25 }}
              />
            </div>
          </div>

          <div className="w-[8%] shrink-0"></div>
        </div>

        {/* X-axis Row (under the Graph, so we offset by the Y-axis width) */}
        <div className="flex w-full mt-2 lg:mt-3">
          <div className="w-[26%] shrink-0"></div>
          {/* Spacer to offset left columns */}
          <div className="w-[66%] flex flex-col shrink-0">
            {/* X-axis Labels */}
            <div className="relative h-4 w-full text-[10px] text-gray-700 font-mono">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((val, idx) => (
                <span
                  key={`val-${val}`}
                  className={`${
                    val % 2 !== 0 ? "font-bold" : ""
                  } absolute -translate-x-1/2 text-center w-4 top-0`}
                  style={{ left: `${idx * 12.5}%` }}
                >
                  {val}
                </span>
              ))}
            </div>

            {/* X-axis Images */}
            <div
              className={`relative w-full mt-1 ${isTabletContext ? "h-[35px] sm:h-[45px] md:h-[55px]" : "h-[25px] sm:h-[30px]"}`}
            >
              {[1, 3, 5, 7, 9].map((val, idx) => (
                <div
                  key={`valence-${val}`}
                  className="absolute top-0 h-full aspect-[4/5] overflow-hidden -translate-x-1/2 flex items-center justify-center"
                  style={{ left: `${idx * 25}%` }}
                >
                  <img
                    src={`/valence ${Math.floor(val / 2) + 1}.png`}
                    alt={`Valence ${val}`}
                    className="w-full h-full object-contain mix-blend-multiply"
                    onError={(e) => {
                      // Fallback text if image not found
                      e.currentTarget.style.display = "none";
                      e.currentTarget.parentElement!.innerHTML =
                        '<div class="text-[8px] text-gray-400">IMG</div>';
                    }}
                  />
                </div>
              ))}
            </div>

            <div className="text-center font-bold uppercase text-[10px] mt-2 mb-1 tracking-wider">
              Valence
            </div>
          </div>
          <div className="w-[8%] shrink-0"></div>
        </div>
      </div>
    );
  }

  return (
    <div
      className={`flex flex-col items-center select-none w-full mx-auto h-full justify-center min-h-0 ${variant === "compact" ? "max-w-full" : "max-w-sm lg:max-w-md"}`}
    >
      {variant === "default" && (
        <div className="flex justify-between w-full px-8 mb-2 dark:text-gray-400 text-gray-500 text-sm font-medium items-center shrink-0 transition-colors duration-200">
          <span>Low Arousal</span>
          <Flame className="w-5 h-5 text-orange-500" />
          <span>High Arousal</span>
        </div>
      )}

      <div
        className={`relative flex items-center justify-center w-full flex-1 min-h-0 min-w-0 ${variant === "compact" ? "p-4" : ""}`}
      >
        {variant === "default" && (
          <div
            className={`flex flex-col items-center dark:text-gray-400 text-gray-500 shrink-0 transition-colors duration-200 mr-2 lg:mr-4`}
          >
            <Frown className="w-5 h-5 lg:w-6 lg:h-6 mb-1 text-blue-400" />
            <span className="font-medium [writing-mode:vertical-lr] rotate-180 text-[10px] lg:text-xs mb-2">
              Negative Valence
            </span>
          </div>
        )}

        {/* Core Emotion Map Area */}
        <div
          ref={mapRef}
          className={`relative aspect-square w-full max-w-full max-h-full ${variant === "compact" ? "bg-white border-l border-b border-gray-400" : "dark:bg-[#1a1c23] bg-white border dark:border-gray-700 border-gray-300 rounded-xl shadow-inner mx-auto"} cursor-crosshair overflow-visible touch-none transition-colors duration-200`}
          onMouseDown={handlePointerDown}
          onMouseMove={handlePointerMove}
          onMouseUp={handlePointerUp}
          onMouseLeave={handlePointerUp}
          onTouchStart={handlePointerDown}
          onTouchMove={handlePointerMove}
          onTouchEnd={handlePointerUp}
        >
          {/* Compact Axis Labels */}
          {variant === "compact" && (
            <>
              {/* Y Axis Labels (1-9) */}
              <div className="absolute top-0 bottom-0 -left-4 w-3 flex flex-col justify-between items-end text-[8px] text-gray-500 font-mono">
                <span>9</span>
                <span>8</span>
                <span>7</span>
                <span>6</span>
                <span>5</span>
                <span>4</span>
                <span>3</span>
                <span>2</span>
                <span>1</span>
              </div>

              {/* X Axis Labels (1-9) */}
              <div className="absolute -bottom-4 left-0 right-0 h-3 flex justify-between items-start text-[8px] text-gray-500 font-mono">
                <span>1</span>
                <span>2</span>
                <span>3</span>
                <span>4</span>
                <span>5</span>
                <span>6</span>
                <span>7</span>
                <span>8</span>
                <span>9</span>
              </div>

              {/* Light grid lines for 1-9 coordinates inside the graph */}
              <div className="absolute inset-0 grid grid-cols-8 grid-rows-8 pointer-events-none">
                {Array.from({ length: 64 }).map((_, i) => (
                  <div
                    key={i}
                    className="border-r border-b border-gray-100 dark:border-gray-100"
                  ></div>
                ))}
              </div>
            </>
          )}

          {variant === "default" && (
            <>
              {/* Grid lines */}
              <div className="absolute inset-0 grid grid-cols-2 grid-rows-2">
                <div className="border-r border-b dark:border-gray-800/60 border-gray-200"></div>
                <div className="border-b dark:border-gray-800/60 border-gray-200"></div>
                <div className="border-r dark:border-gray-800/60 border-gray-200"></div>
                <div></div>
              </div>

              {/* Axes markers */}
              <div className="absolute top-0 bottom-0 left-1/2 w-px dark:bg-gray-700/80 bg-gray-300 -translate-x-1/2"></div>
              <div className="absolute left-0 right-0 top-1/2 h-px dark:bg-gray-700/80 bg-gray-300 -translate-y-1/2"></div>

              {/* Quadrant labels */}
              <span className="absolute top-2 right-2 text-[10px] dark:text-gray-500/50 text-gray-400 uppercase tracking-wider font-semibold pointer-events-none">
                Excited
              </span>
              <span className="absolute top-2 left-2 text-[10px] dark:text-gray-500/50 text-gray-400 uppercase tracking-wider font-semibold pointer-events-none">
                Stressed
              </span>
              <span className="absolute bottom-2 right-2 text-[10px] dark:text-gray-500/50 text-gray-400 uppercase tracking-wider font-semibold pointer-events-none">
                Calm
              </span>
              <span className="absolute bottom-2 left-2 text-[10px] dark:text-gray-500/50 text-gray-400 uppercase tracking-wider font-semibold pointer-events-none">
                Sad
              </span>
            </>
          )}

          {/* Current Selection Marker */}
          <motion.div
            className={`absolute rounded-full pointer-events-none ${variant === "compact" ? "w-2 h-2 bg-red-700" : "w-4 h-4 bg-red-500 border-2 border-white shadow-[0_0_10px_rgba(239,68,68,0.8)]"}`}
            style={{
              left: `${xPos}%`,
              top: `${yPos}%`,
              x: "-50%",
              y: "-50%",
            }}
            transition={{ type: "spring", stiffness: 400, damping: 25 }}
          />

          {/* Origin axes for compact */}
          {variant === "compact" && (
            <>
              <div className="absolute top-0 bottom-0 left-1/2 w-px bg-gray-300 pointer-events-none"></div>
              <div className="absolute left-0 right-0 top-1/2 h-px bg-gray-300 pointer-events-none"></div>
            </>
          )}
        </div>

        {variant === "default" && (
          <div
            className={`flex flex-col items-center dark:text-gray-400 text-gray-500 shrink-0 transition-colors duration-200 ml-2 lg:ml-4`}
          >
            <Smile className="w-5 h-5 lg:w-6 lg:h-6 mb-1 text-green-400" />
            <span className="font-medium [writing-mode:vertical-lr] rotate-180 text-[10px] lg:text-xs">
              Positive Valence
            </span>
          </div>
        )}
      </div>

      {variant === "default" && (
        <div className="flex justify-between w-full px-8 mt-2 dark:text-gray-400 text-gray-500 text-sm font-medium items-center shrink-0 transition-colors duration-200">
          <span>Low</span>
          <Snowflake className="w-5 h-5 text-cyan-400" />
          <span>High</span>
        </div>
      )}
    </div>
  );
}
