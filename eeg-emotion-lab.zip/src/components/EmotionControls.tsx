import React, { useState, useEffect } from "react";
import { useExperimentStore } from "../store";
import { Save, Play, Square, CheckCircle2, Archive, X } from "lucide-react";

// Formats the elapsed session seconds into a MM:SS string structure
const formatTime = (seconds: number) => {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
};

export function EmotionControls({
  compact = false,
  hideSessionControls = false,
}: {
  compact?: boolean;
  hideSessionControls?: boolean;
}) {
  const { valence, arousal, isRecording, toggleRecording, addLabel, labels } =
    useExperimentStore();
  const [showSavedFeedback, setShowSavedFeedback] = useState(false);
  const [showArchive, setShowArchive] = useState(false);

  // Directly handle saving a manual annotation log
  const handleSave = () => {
    addLabel();
    setShowSavedFeedback(true);
  };

  // Auto-hide the saved feedback UI state after a short delay
  useEffect(() => {
    if (showSavedFeedback) {
      const timer = setTimeout(() => setShowSavedFeedback(false), 1000);
      return () => clearTimeout(timer);
    }
  }, [showSavedFeedback]);

  return (
    <div
      className={`flex flex-col ${compact ? "gap-2" : "gap-4 dark:bg-[#1a1c23] bg-gray-50 border dark:border-gray-800 border-gray-200 rounded-xl p-5 shadow-sm transition-colors duration-200"}`}
    >
      {!compact && (
        <div className="flex justify-between items-center mb-2">
          <h3 className="dark:text-gray-300 text-gray-700 font-medium tracking-tight">
            Current Label
          </h3>
          <span className="text-xs dark:text-gray-500 text-gray-500">
            {labels.length} saved
          </span>
        </div>
      )}

      {!compact && (
        <div className={`grid grid-cols-2 ${compact ? "gap-2" : "gap-4 mb-2"}`}>
          <div
            className={`dark:bg-gray-900 bg-white rounded-xl border dark:border-gray-800 border-gray-200 flex justify-between items-center transition-colors duration-200 ${compact ? "p-2" : "p-3 md:p-4"}`}
          >
            <span
              className={`dark:text-gray-500 text-gray-500 font-bold uppercase tracking-wider ${compact ? "text-[10px]" : "text-xs md:text-sm"}`}
            >
              Valence
            </span>
            <span
              className={`font-mono font-medium text-blue-500 dark:text-blue-400 ${compact ? "text-sm" : "text-xl md:text-2xl"}`}
            >
              {valence.toFixed(1)}
            </span>
          </div>
          <div
            className={`dark:bg-gray-900 bg-white rounded-xl border dark:border-gray-800 border-gray-200 flex justify-between items-center transition-colors duration-200 ${compact ? "p-2" : "p-3 md:p-4"}`}
          >
            <span
              className={`dark:text-gray-500 text-gray-500 font-bold uppercase tracking-wider ${compact ? "text-[10px]" : "text-xs md:text-sm"}`}
            >
              Arousal
            </span>
            <span
              className={`font-mono font-medium text-orange-500 dark:text-orange-400 ${compact ? "text-sm" : "text-xl md:text-2xl"}`}
            >
              {arousal.toFixed(1)}
            </span>
          </div>
        </div>
      )}

      <div className={`flex mt-auto flex-col ${compact ? "gap-2" : "gap-3"}`}>
        {!compact && !hideSessionControls && (
          <button
            onClick={toggleRecording}
            className={`w-full flex items-center justify-center gap-2 rounded-xl font-bold transition-colors py-3 md:py-4 md:text-lg ${
              isRecording
                ? "bg-red-500/10 text-red-600 dark:text-red-500 border border-red-500/20 hover:bg-red-500/20"
                : "bg-green-500/10 text-green-600 dark:text-green-500 border border-green-500/20 hover:bg-green-500/20"
            }`}
          >
            {isRecording ? (
              <>
                <Square className="w-5 h-5 fill-current" />
                Stop Session
              </>
            ) : (
              <>
                <Play className="w-5 h-5 fill-current" />
                Start Session
              </>
            )}
          </button>
        )}

        <div className={`grid grid-cols-2 gap-2 ${compact ? "" : "mt-1"}`}>
          <button
            onClick={() => setShowArchive(true)}
            className={`flex items-center justify-center gap-2 rounded-xl font-semibold transition-all ${compact ? "py-2.5 text-sm" : "py-3 md:py-4 md:text-base"} dark:bg-gray-800 bg-gray-200 dark:text-gray-300 text-gray-700 dark:hover:bg-gray-700 hover:bg-gray-300`}
          >
            <Archive className={`${compact ? "w-4 h-4" : "w-5 h-5"}`} />
            {compact ? "Archive" : "View Archive"}
          </button>

          <button
            onClick={handleSave}
            disabled={!isRecording}
            className={`flex items-center justify-center gap-2 rounded-xl font-semibold transition-all ${compact ? "py-2.5 text-sm" : "py-3 md:py-4 md:text-base"} ${
              !isRecording
                ? "dark:bg-gray-800 bg-gray-200 dark:text-gray-600 text-gray-400 cursor-not-allowed border dark:border-gray-800 border-gray-200"
                : showSavedFeedback
                  ? "bg-emerald-500 text-white shadow-lg shadow-emerald-500/20"
                  : "bg-blue-600 text-white hover:bg-blue-500 shadow-lg shadow-blue-500/20"
            }`}
          >
            {showSavedFeedback ? (
              <>
                <CheckCircle2
                  className={`${compact ? "w-4 h-4" : "w-5 h-5"}`}
                />
                {compact ? "Done" : "Saved!"}
              </>
            ) : (
              <>
                <Save className={`${compact ? "w-4 h-4" : "w-5 h-5"}`} />
                {compact ? "Submit" : "Submit Label"}
              </>
            )}
          </button>
        </div>
      </div>

      {compact && labels.length > 0 && (
        <div className="text-center mt-1">
          <span className="text-[10px] dark:text-gray-500 text-gray-500">
            {labels.length} annotation{labels.length > 1 ? "s" : ""} saved
          </span>
        </div>
      )}

      {/* Archive Modal */}
      {showArchive && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-[#1a1c23] border dark:border-gray-800 border-gray-200 rounded-2xl p-6 w-full max-w-md shadow-2xl flex flex-col max-h-[80vh] transition-colors duration-200 relative">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h2 className="text-xl font-bold dark:text-white text-gray-900 tracking-tight">
                  Session Archive
                </h2>
                <p className="text-xs dark:text-gray-400 text-gray-500 mt-1">
                  Recorded labels for the current session
                </p>
              </div>
              <button
                onClick={() => setShowArchive(false)}
                className="p-2 rounded-lg dark:hover:bg-gray-800 hover:bg-gray-100 dark:text-gray-400 text-gray-500 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto no-scrollbar flex flex-col gap-2 rounded-xl">
              {labels.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <Archive className="w-12 h-12 dark:text-gray-700 text-gray-300 mb-3" />
                  <p className="dark:text-gray-400 text-gray-500 font-medium">
                    No annotations yet
                  </p>
                  <p className="text-xs dark:text-gray-500 text-gray-400 mt-1">
                    Submit labels during an active session to see them here.
                  </p>
                </div>
              ) : (
                labels.map((lbl, idx) => (
                  <div
                    key={idx}
                    className="dark:bg-gray-900/50 bg-gray-50 p-3 lg:p-4 rounded-xl border dark:border-gray-800 border-gray-200 flex justify-between items-center"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full dark:bg-gray-800 bg-gray-200 flex items-center justify-center text-xs font-bold dark:text-gray-400 text-gray-600">
                        {idx + 1}
                      </div>
                      <span className="font-mono text-sm dark:text-gray-300 text-gray-700 font-medium">
                        {formatTime(lbl.timestamp)}
                      </span>
                    </div>
                    <div className="flex gap-4">
                      <div className="flex flex-col items-end">
                        <span className="text-[10px] uppercase font-bold dark:text-gray-500 text-gray-400">
                          Valence
                        </span>
                        <span className="text-sm font-mono font-bold dark:text-blue-400 text-blue-500">
                          {lbl.valence.toFixed(1)}
                        </span>
                      </div>
                      <div className="flex flex-col items-end">
                        <span className="text-[10px] uppercase font-bold dark:text-gray-500 text-gray-400">
                          Arousal
                        </span>
                        <span className="text-sm font-mono font-bold dark:text-orange-400 text-orange-500">
                          {lbl.arousal.toFixed(1)}
                        </span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="mt-4 pt-4 border-t dark:border-gray-800 border-gray-200">
              <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-3">
                <p className="text-xs dark:text-blue-400 text-blue-700 flex items-start gap-2">
                  <span className="text-lg leading-none">ℹ️</span>
                  <span>
                    Ready for backend integration. These records will be synced
                    to the database.
                  </span>
                </p>
              </div>
              <button
                onClick={() => setShowArchive(false)}
                className="w-full mt-3 py-3 rounded-xl font-bold dark:bg-gray-800 bg-gray-200 dark:text-white text-gray-900 dark:hover:bg-gray-700 hover:bg-gray-300 transition-colors"
              >
                Close Archive
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
