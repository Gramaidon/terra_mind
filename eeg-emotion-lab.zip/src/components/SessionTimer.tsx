import React, { useEffect } from "react";
import { useExperimentStore } from "../store";
import { Clock } from "lucide-react";
import { useLocation } from "react-router-dom";

export function SessionTimer() {
  const { sessionTime, isRecording, tickSessionTime } = useExperimentStore();
  const location = useLocation();
  const isDeveloper = location.pathname === "/" || location.pathname === "/dev";

  // Manages the global session clock tick when recording is active
  useEffect(() => {
    let interval: number;
    // Only the developer view manages the tick to prevent double-counting across tabs
    if (isRecording && isDeveloper) {
      interval = window.setInterval(() => {
        tickSessionTime();
        useExperimentStore.getState().addLabel(); // save label perdetik
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRecording, tickSessionTime, isDeveloper]);

  // Formats the elapsed session seconds into a MM:SS string
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div className="flex items-center gap-3 dark:bg-[#1a1c23] bg-gray-100 px-3 md:px-4 py-1.5 md:py-2 rounded-lg border dark:border-gray-800 border-gray-200 shadow-sm transition-colors duration-200">
      <Clock
        className={`w-4 h-4 ${isRecording ? "text-red-500 animate-pulse" : "dark:text-gray-500 text-gray-400"}`}
      />
      <span className="font-mono text-lg md:text-xl font-medium tracking-wider dark:text-gray-200 text-gray-800">
        {formatTime(sessionTime)}
      </span>
      {isRecording && (
        <span className="flex h-2 w-2 relative ml-0.5 md:ml-1">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
        </span>
      )}
    </div>
  );
}
