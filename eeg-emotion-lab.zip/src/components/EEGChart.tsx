import React, { useMemo } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
} from "recharts";
import { useExperimentStore } from "../store";
import { Activity } from "lucide-react";

export function EEGChart() {
  const { eegData, isRecording } = useExperimentStore();

  const currentValues = useMemo(() => {
    if (eegData.length === 0) return { theta: 0, alpha: 0, beta: 0, gamma: 0 };
    const last = eegData[eegData.length - 1];
    return {
      theta: last.theta.toFixed(1),
      alpha: last.alpha.toFixed(1),
      beta: last.beta.toFixed(1),
      gamma: last.gamma.toFixed(1),
    };
  }, [eegData]);

  // Use a fixed window for the chart to keep it moving nicely
  const displayData = eegData.slice(-60); // Last 6 seconds at 10Hz

  return (
    <div className="dark:bg-[#1a1c23] bg-white border dark:border-gray-800 border-gray-200 rounded-xl p-4 shadow-sm h-full flex flex-col transition-colors duration-200">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Activity
            className={`w-5 h-5 ${isRecording ? "text-green-500 animate-pulse" : "dark:text-gray-500 text-gray-400"}`}
          />
          <h2 className="dark:text-gray-200 text-gray-800 font-semibold tracking-tight">
            {isRecording ? "Realtime EEG Data" : "Raw Data"}
          </h2>
        </div>
        <div className="flex gap-4">
          <div className="flex flex-col items-end">
            <span className="text-[10px] uppercase dark:text-gray-500 text-gray-400 font-bold">
              Theta (4-8Hz)
            </span>
            <span className="text-sm font-mono text-emerald-500 dark:text-emerald-400">
              {currentValues.theta} μV
            </span>
          </div>
          <div className="flex flex-col items-end">
            <span className="text-[10px] uppercase dark:text-gray-500 text-gray-400 font-bold">
              Alpha (8-12Hz)
            </span>
            <span className="text-sm font-mono text-blue-500 dark:text-blue-400">
              {currentValues.alpha} μV
            </span>
          </div>
          <div className="flex flex-col items-end">
            <span className="text-[10px] uppercase dark:text-gray-500 text-gray-400 font-bold">
              Beta (12-30Hz)
            </span>
            <span className="text-sm font-mono text-purple-500 dark:text-purple-400">
              {currentValues.beta} μV
            </span>
          </div>
          <div className="flex flex-col items-end">
            <span className="text-[10px] uppercase dark:text-gray-500 text-gray-400 font-bold">
              Gamma (30+Hz)
            </span>
            <span className="text-sm font-mono text-rose-500 dark:text-rose-400">
              {currentValues.gamma} μV
            </span>
          </div>
        </div>
      </div>

      <div className="flex-1 min-h-[150px] relative">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart
            data={displayData}
            margin={{ top: 5, right: 0, left: -20, bottom: 0 }}
          >
            <CartesianGrid
              strokeDasharray="3 3"
              className="stroke-gray-200 dark:stroke-gray-700/50"
              vertical={false}
            />
            <XAxis dataKey="time" hide />
            <YAxis
              domain={["auto", "auto"]}
              className="text-gray-400 dark:text-gray-500"
              tick={{ fontSize: 10 }}
              tickLine={false}
              axisLine={false}
            />
            <Line
              type="monotone"
              dataKey="theta"
              stroke="#10b981"
              strokeWidth={1.5}
              dot={false}
              isAnimationActive={false}
            />
            <Line
              type="monotone"
              dataKey="alpha"
              stroke="#3b82f6"
              strokeWidth={1.5}
              dot={false}
              isAnimationActive={false}
            />
            <Line
              type="monotone"
              dataKey="beta"
              stroke="#8b5cf6"
              strokeWidth={1.5}
              dot={false}
              isAnimationActive={false}
            />
            <Line
              type="monotone"
              dataKey="gamma"
              stroke="#f43f5e"
              strokeWidth={1.5}
              dot={false}
              isAnimationActive={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
