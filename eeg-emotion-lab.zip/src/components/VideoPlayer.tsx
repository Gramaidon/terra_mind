import React, { useRef, useEffect } from "react";
import { useExperimentStore } from "../store";
import { useLocation } from "react-router-dom";

export function VideoPlayer() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const { isRecording, setVideoTime, videoTime } = useExperimentStore();
  const location = useLocation();
  const isDeveloper = location.pathname === "/" || location.pathname === "/dev";
  const isParticipantScreen = location.pathname === "/screen";

  // Mengatur pemutaran video secara otomatis saat recording dimulai atau dijeda
  useEffect(() => {
    if (isRecording) {
      videoRef.current?.play().catch(console.error);
    } else {
      videoRef.current?.pause();
      if (videoRef.current) {
        videoRef.current.currentTime = 0;
      }
    }
  }, [isRecording]);

  // Menyesuaikan waktu (sinkronisasi) pemutaran video pada layar partisipan (subject/screen)
  useEffect(() => {
    if (isParticipantScreen && videoRef.current) {
      if (Math.abs(videoRef.current.currentTime - videoTime) > 2) {
        videoRef.current.currentTime = videoTime;
      }
      if (isRecording && videoRef.current.paused) {
        videoRef.current.play().catch(console.error);
      }
    }
  }, [videoTime, isParticipantScreen, isRecording]);

  // Memperbarui waktu video pada store agar tersinkronisasi ke tab lain (saat berjalan di perangkat dev)
  const handleTimeUpdate = () => {
    if (videoRef.current && isDeveloper) {
      setVideoTime(Math.floor(videoRef.current.currentTime));
    }
  };

  return (
    <div
      className={`relative w-full overflow-hidden flex items-center justify-center bg-black ${isDeveloper ? "h-full aspect-video rounded-lg dark:border-gray-800 border-gray-600 shadow-xl" : "h-full"}`}
    >
      <video
        ref={videoRef}
        // TODO(Backend): Ganti src video di bawah dengan URL dinamis dari backend API untuk media stimulus.
        src="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4"
        className="w-full h-full object-contain"
        onTimeUpdate={handleTimeUpdate}
        playsInline
        muted // Muted for preview environment
      />

      {!isRecording && (
        <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center text-gray-300 backdrop-blur-sm">
          <svg
            className="w-16 h-16 mb-4 opacity-50"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1}
              d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"
            />
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1}
              d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
            />
          </svg>
          <span className="text-sm md:text-base font-medium tracking-widest uppercase">
            Waiting for session start
          </span>
        </div>
      )}
    </div>
  );
}
