import { useEffect, useRef } from "react";
import { useExperimentStore } from "./store";

// Simulates a WebSocket connection for receiving realtime EEG data
export function useMockEEG(isDeveloper: boolean) {
  const { addEegData } = useExperimentStore();
  const tRef = useRef(0);

  useEffect(() => {
    let interval: number;

    // Generate mock data completely on the developer view, even before session starts
    // TODO(Backend): Ganti fungsi setInterval ini dengan listener WebSocket/API
    // untuk stream data realtime dari perangkat EEG. Panggil `addEegData` setiap kali mendapat data baru.
    if (isDeveloper) {
      interval = window.setInterval(() => {
        tRef.current += 0.1;

        // Generate simulated EEG wave patterns using sine waves with some noise
        const noise = () => (Math.random() - 0.5) * 5;

        const theta = 5 + 3 * Math.sin(tRef.current * 1.5) + noise();
        const alpha = 10 + 5 * Math.sin(tRef.current * 2) + noise();
        const beta = 15 + 8 * Math.sin(tRef.current * 3) + noise();
        const gamma = 20 + 4 * Math.sin(tRef.current * 5) + noise();

        addEegData({
          theta: Math.max(0, theta),
          alpha: Math.max(0, alpha),
          beta: Math.max(0, beta),
          gamma: Math.max(0, gamma),
        });
      }, 100); // 10Hz sampling for UI purposes
    } else {
      tRef.current = 0;
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isDeveloper, addEegData]);
}
