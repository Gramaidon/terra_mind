import React, { useEffect } from "react";
import { Routes, Route, Link, useLocation } from "react-router-dom";
import { useExperimentStore } from "./store";
import { useMockEEG } from "./useMockEEG";
import { VideoPlayer } from "./components/VideoPlayer";
import { EmotionMap } from "./components/EmotionMap";
import { EEGChart } from "./components/EEGChart";
import { SessionTimer } from "./components/SessionTimer";
import { EmotionControls } from "./components/EmotionControls";
import {
  BrainCircuit,
  Maximize2,
  Minimize2,
  Download,
  Moon,
  Sun,
} from "lucide-react";

export default function App() {
  const {
    isFullscreen,
    setFullscreen,
    labels,
    isRecording,
    theme,
    toggleTheme,
  } = useExperimentStore();

  const location = useLocation();
  const isDeveloper = location.pathname === "/" || location.pathname === "/dev";

  useMockEEG(isDeveloper);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch((err) => {
        console.error(`Error attempting to enable fullscreen: ${err.message}`);
      });
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
    }
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener("fullscreenchange", handleFullscreenChange);
    return () =>
      document.removeEventListener("fullscreenchange", handleFullscreenChange);
  }, [setFullscreen]);

  const exportData = () => {
    if (labels.length === 0) return;
    const dataStr =
      "data:text/json;charset=utf-8," +
      encodeURIComponent(JSON.stringify(labels, null, 2));
    const downloadAnchorNode = document.createElement("a");
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute(
      "download",
      `experiment_session_${Date.now()}.json`,
    );
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  return (
    <div
      className={`min-h-screen font-sans selection:bg-blue-500/30 transition-colors duration-200 ${theme === "dark" ? "dark bg-[#0f1115] text-gray-200" : "bg-gray-50 text-gray-900"}`}
    >
      {isDeveloper && (
        <header className="border-b transition-colors duration-200 dark:border-gray-800 border-gray-200 dark:bg-[#16181d] bg-white">
          <div className="max-w-[1600px] mx-auto px-4 md:px-6 h-16 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="dark:bg-blue-500/10 bg-blue-100 p-2 rounded-lg">
                <BrainCircuit className="w-6 h-6 dark:text-blue-400 text-blue-600" />
              </div>
              <div>
                <h1 className="font-semibold text-lg leading-none dark:text-white text-gray-900 tracking-tight">
                  AffectiveUI Lab
                </h1>
                <div className="flex gap-2 items-center">
                  <p className="text-[10px] md:text-xs dark:text-gray-500 text-gray-400 font-mono mt-1">
                    SESSION: AF-492
                  </p>
                  <div
                    className="flex bg-gray-200 dark:bg-gray-800 rounded mt-0.5"
                    style={{ padding: "2px" }}
                  >
                    <Link
                      to="/dev"
                      className={`text-[9px] font-bold uppercase px-1.5 py-0.5 rounded transition-colors ${location.pathname === "/" || location.pathname === "/dev" ? "bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm" : "text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"}`}
                    >
                      Dev
                    </Link>
                    <Link
                      to="/screen"
                      target="_blank"
                      className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded transition-colors text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
                    >
                      Screen ↗
                    </Link>
                    <Link
                      to="/tablet"
                      target="_blank"
                      className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded transition-colors text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
                    >
                      Tablet ↗
                    </Link>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2 md:gap-4">
              <SessionTimer />
              <div className="h-6 w-px dark:bg-gray-800 bg-gray-200 mx-1 md:mx-2" />

              <button
                onClick={toggleTheme}
                className="p-2 dark:text-gray-400 text-gray-500 dark:hover:text-white hover:text-gray-900 dark:hover:bg-gray-800 hover:bg-gray-100 rounded-md transition-colors"
                title="Toggle Theme"
              >
                {theme === "dark" ? (
                  <Sun className="w-5 h-5" />
                ) : (
                  <Moon className="w-5 h-5" />
                )}
              </button>
              <button
                onClick={exportData}
                disabled={labels.length === 0 || isRecording}
                className={`p-2 rounded-md transition-colors hidden md:block ${
                  labels.length > 0 && !isRecording
                    ? "dark:text-gray-300 text-gray-600 dark:hover:bg-gray-800 hover:bg-gray-100 dark:hover:text-white hover:text-gray-900"
                    : "dark:text-gray-700 text-gray-300 cursor-not-allowed"
                }`}
                title="Export Annotations (JSON)"
              >
                <Download className="w-5 h-5" />
              </button>
              <button
                onClick={toggleFullscreen}
                className="p-2 dark:text-gray-400 text-gray-500 dark:hover:text-white hover:text-gray-900 dark:hover:bg-gray-800 hover:bg-gray-100 rounded-md transition-colors"
                title="Toggle Fullscreen"
              >
                {isFullscreen ? (
                  <Minimize2 className="w-5 h-5" />
                ) : (
                  <Maximize2 className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>
        </header>
      )}

      <Routes>
        <Route
          path="/"
          element={
            <main className="max-w-[1600px] mx-auto p-4 md:p-6 w-full min-h-[calc(100svh-4rem)] flex flex-col">
              <div className="flex-1 min-h-[270px] flex flex-col lg:flex-row gap-4 md:gap-6">
                <div className="flex flex-col gap-4 md:gap-6 lg:w-7/12 xl:w-8/12 min-h-[270px] lg:overflow-visible overflow-y-auto no-scrollbar pb-2 lg:pb-0">
                  <div className="dark:bg-[#16181d] bg-white rounded-2xl border dark:border-gray-800 border-gray-200 p-4 shadow-xl flex flex-col lg:flex-1 shrink-0 lg:shrink min-h-[250px] md:min-h-[350px] lg:min-h-[270px] transition-colors duration-200">
                    <h2 className="text-xs font-bold uppercase tracking-widest dark:text-gray-500 text-gray-400 mb-3 ml-2">
                      Stimulus Playback
                    </h2>
                    <div className="flex-1 lg:min-h-[270px] rounded-xl overflow-hidden shadow-inner bg-black flex items-center justify-center relative">
                      <VideoPlayer />
                    </div>
                  </div>
                  <div className="h-[200px] md:h-[240px] lg:h-[260px] xl:h-[280px] dark:bg-[#16181d] bg-white rounded-2xl border dark:border-gray-800 border-gray-200 p-4 shadow-xl shrink-0 transition-colors duration-200">
                    <EEGChart />
                  </div>
                </div>
                <div className="flex flex-col gap-4 md:gap-6 lg:w-5/12 xl:w-4/12 min-h-[270px] shrink-0">
                  <div className="dark:bg-[#16181d] bg-white rounded-2xl border dark:border-gray-800 border-gray-200 p-4 md:p-5 lg:p-6 flex flex-col shadow-xl flex-1 min-h-[450px] lg:min-h-[270px] pb-5 transition-colors duration-200">
                    <div className="mb-4 lg:mb-6 shrink-0">
                      <h2 className="text-lg md:text-xl font-semibold dark:text-white text-gray-900 tracking-tight">
                        Affective Annotation
                      </h2>
                      <p className="text-sm dark:text-gray-400 text-gray-500 mt-1">
                        Select your current emotional state.
                      </p>
                    </div>
                    <div className="flex-1 flex items-center justify-center min-h-[200px] lg:min-h-[270px] py-2 lg:py-4">
                      <EmotionMap variant="sam" />
                    </div>
                    <div className="mt-4 pt-5 border-t dark:border-gray-800/50 border-gray-200 shrink-0">
                      <EmotionControls />
                    </div>
                  </div>
                </div>
              </div>
            </main>
          }
        />
        <Route
          path="/dev"
          element={
            <main className="max-w-[1600px] mx-auto p-4 md:p-6 w-full min-h-[calc(100svh-4rem)] flex flex-col">
              <div className="flex-1 min-h-[270px] flex flex-col lg:flex-row gap-4 md:gap-6">
                <div className="flex flex-col gap-4 md:gap-6 lg:w-7/12 xl:w-8/12 min-h-[270px] lg:overflow-visible overflow-y-auto no-scrollbar pb-2 lg:pb-0">
                  <div className="dark:bg-[#16181d] bg-white rounded-2xl border dark:border-gray-800 border-gray-200 p-4 shadow-xl flex flex-col lg:flex-1 shrink-0 lg:shrink min-h-[250px] md:min-h-[350px] lg:min-h-[270px] transition-colors duration-200">
                    <h2 className="text-xs font-bold uppercase tracking-widest dark:text-gray-500 text-gray-400 mb-3 ml-2">
                      Stimulus Playback
                    </h2>
                    <div className="flex-1 lg:min-h-[270px] rounded-xl overflow-hidden shadow-inner bg-black flex items-center justify-center relative">
                      <VideoPlayer />
                    </div>
                  </div>
                  <div className="h-[200px] md:h-[240px] lg:h-[260px] xl:h-[280px] dark:bg-[#16181d] bg-white rounded-2xl border dark:border-gray-800 border-gray-200 p-4 shadow-xl shrink-0 transition-colors duration-200">
                    <EEGChart />
                  </div>
                </div>
                <div className="flex flex-col gap-4 md:gap-6 lg:w-5/12 xl:w-4/12 min-h-[270px] shrink-0">
                  <div className="dark:bg-[#16181d] bg-white rounded-2xl border dark:border-gray-800 border-gray-200 p-4 md:p-5 lg:p-6 flex flex-col shadow-xl flex-1 min-h-[450px] lg:min-h-[270px] pb-5 transition-colors duration-200">
                    <div className="mb-4 lg:mb-6 shrink-0">
                      <h2 className="text-lg md:text-xl font-semibold dark:text-white text-gray-900 tracking-tight">
                        Affective Annotation
                      </h2>
                      <p className="text-sm dark:text-gray-400 text-gray-500 mt-1">
                        Select your current emotional state.
                      </p>
                    </div>
                    <div className="flex-1 flex items-center justify-center min-h-[200px] lg:min-h-[270px] py-2 lg:py-4">
                      <EmotionMap variant="sam" />
                    </div>
                    <div className="mt-4 pt-5 border-t dark:border-gray-800/50 border-gray-200 shrink-0">
                      <EmotionControls />
                    </div>
                  </div>
                </div>
              </div>
            </main>
          }
        />
        <Route
          path="/screen"
          element={
            <main className="w-full h-[100svh] relative bg-black flex flex-col items-center justify-center overflow-hidden">
              <div className="absolute inset-0 w-full h-full flex flex-col">
                <VideoPlayer />
              </div>

              <div className="absolute top-4 left-4 z-20 flex gap-2">
                <Link
                  to="/dev"
                  className="px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-white/50 hover:text-white bg-black/20 hover:bg-black/50 backdrop-blur-sm rounded-lg border border-white/10 transition-all shadow-xl"
                >
                  Back to Dev
                </Link>
                <button
                  onClick={toggleTheme}
                  className="p-1.5 text-white/50 hover:text-white bg-black/20 hover:bg-black/50 backdrop-blur-sm rounded-lg border border-white/10 transition-all shadow-xl"
                  title="Toggle Theme"
                >
                  {theme === "dark" ? (
                    <Sun className="w-4 h-4" />
                  ) : (
                    <Moon className="w-4 h-4" />
                  )}
                </button>
              </div>

              <div className="absolute top-4 right-4 z-20 w-56 sm:w-64 md:w-72 bg-white rounded-lg border-[3px] border-[#12b115] shadow-2xl p-1 flex flex-col pt-2">
                <EmotionMap variant="sam" />
              </div>
            </main>
          }
        />
        <Route
          path="/tablet"
          element={
            <main className="w-full h-[100svh] flex flex-col items-center justify-center p-4">
              <div className="absolute top-4 left-4 z-20 flex gap-2">
                <Link
                  to="/dev"
                  className="px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white bg-white/50 hover:bg-white/80 dark:bg-black/20 dark:hover:bg-black/50 backdrop-blur-sm rounded-lg border border-gray-200 dark:border-white/10 transition-all shadow-sm"
                >
                  Back to Dev
                </Link>
                <button
                  onClick={toggleTheme}
                  className="p-1.5 text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white bg-white/50 hover:bg-white/80 dark:bg-black/20 dark:hover:bg-black/50 backdrop-blur-sm rounded-lg border border-gray-200 dark:border-white/10 transition-all shadow-sm"
                  title="Toggle Theme"
                >
                  {theme === "dark" ? (
                    <Sun className="w-4 h-4" />
                  ) : (
                    <Moon className="w-4 h-4" />
                  )}
                </button>
              </div>

              <div className="w-full max-w-lg mx-auto bg-white dark:bg-[#16181d] rounded-3xl border-4 border-gray-200 dark:border-gray-800 shadow-2xl flex flex-col p-6 transition-colors duration-200">
                <div className="mb-6 mt-2 text-center">
                  <h2 className="text-2xl font-bold dark:text-white text-gray-900 tracking-tight">
                    Affective Annotation
                  </h2>
                  <p className="dark:text-gray-400 text-gray-500 mt-2">
                    Adjust the point to match how you feel right now.
                  </p>
                </div>
                <div className="flex-1 min-h-[350px] md:min-h-[400px] flex flex-col items-center justify-center py-4 mb-6 overflow-y-auto">
                  {/* Map emotion controls mapping for user on tablet */}
                  <EmotionMap
                    variant="sam"
                    className="max-w-[320px] md:max-w-[420px]"
                    isTabletContext={true}
                  />
                </div>
              </div>
            </main>
          }
        />
      </Routes>
    </div>
  );
}
